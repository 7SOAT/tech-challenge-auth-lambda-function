exports.handler = async (event, context) => {
    return JSON.stringify({ message: "Hello, world!"});
};