export const handler = async (event, context) => {
    return JSON.parse({ message: "Hello, world!"});
};